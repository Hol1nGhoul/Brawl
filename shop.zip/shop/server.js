'use strict';
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const multer = require('multer');
const cfg = require('./src/config');
require('./src/db');
const auth = require('./src/auth');
const publicRoutes = require('./src/routes/public');
const adminRoutes = require('./src/routes/admin');

auth.ensureAdminPassword();

const app = express();
app.disable('x-powered-by');
if (cfg.TRUST_PROXY) app.set('trust proxy', cfg.TRUST_PROXY);

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'"],
      'img-src': ["'self'", 'data:', 'blob:'], // blob: — превью картинки в админке до загрузки
      'connect-src': ["'self'"],
      'form-action': ["'self'"],
      'frame-ancestors': ["'none'"],
      'upgrade-insecure-requests': cfg.IS_PROD ? [] : null,
    },
  },
  strictTransportSecurity: cfg.IS_PROD,
}));

app.use(express.json({ limit: '200kb' }));

app.use('/api', publicRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', (req, res) => res.status(404).json({ error: 'Не найдено' }));

app.use('/uploads', express.static(cfg.UPLOAD_DIR, { maxAge: '30d', immutable: true, index: false }));
app.get(['/admin', '/admin/'], (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin', 'index.html')));
app.use(express.static(path.join(__dirname, 'public'), { index: 'index.html', maxAge: cfg.IS_PROD ? '1h' : 0 }));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', 'index.html')));

// Ошибки: понятное сообщение для пользователя, детали — только в лог.
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    const msg = err.code === 'LIMIT_FILE_SIZE' ? 'Картинка больше 3 МБ' : 'Ошибка загрузки файла';
    return res.status(400).json({ error: msg });
  }
  if (err.type === 'entity.parse.failed' || err.type === 'entity.too.large') {
    return res.status(400).json({ error: 'Некорректный запрос' });
  }
  if (err.status && err.status < 500) return res.status(err.status).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

app.listen(cfg.PORT, cfg.HOST, () => {
  console.log(`Магазин запущен: http://localhost:${cfg.PORT}  (админка: /admin)`);
});
