'use strict';

class BadRequest extends Error {
  constructor(msg) { super(msg); this.status = 400; }
}

// Строка: обрезаем пробелы, режем управляющие символы, ограничиваем длину.
function str(v, max, { required = false, field = 'Поле', multiline = false } = {}) {
  let s = v == null ? '' : String(v);
  s = s.replace(multiline ? /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g : /[\u0000-\u001F\u007F]/g, '').trim();
  if (required && !s) throw new BadRequest(`${field}: обязательно для заполнения`);
  if (s.length > max) throw new BadRequest(`${field}: не длиннее ${max} символов`);
  return s;
}

function int(v, min, max, { field = 'Число', optional = false } = {}) {
  if (optional && (v === '' || v == null)) return null;
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new BadRequest(`${field}: целое число от ${min} до ${max}`);
  return n;
}

function bool(v) {
  return v === true || v === 1 || v === '1' || v === 'true' || v === 'on';
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const TG_RE = /^@?[A-Za-z0-9_]{4,32}$/;

module.exports = { BadRequest, str, int, bool, EMAIL_RE, TG_RE };
