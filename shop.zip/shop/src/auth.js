'use strict';
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { db, getSetting, setSetting } = require('./db');
const { ADMIN_PASSWORD, SESSION_DAYS, IS_PROD } = require('./config');

const COOKIE = 'sid';
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

// Первый запуск: задаём пароль администратора.
function ensureAdminPassword() {
  if (getSetting('admin_password_hash')) return;
  let password = ADMIN_PASSWORD;
  if (!password) {
    password = crypto.randomBytes(9).toString('base64url');
    console.log('\n==============================================');
    console.log(' Пароль администратора (сохраните его!):');
    console.log(' ' + password);
    console.log(' Сменить можно в админке → «Настройки».');
    console.log('==============================================\n');
  }
  setSetting('admin_password_hash', bcrypt.hashSync(password, 12));
}

function checkPassword(password) {
  const hash = getSetting('admin_password_hash');
  return typeof password === 'string' && !!hash && bcrypt.compareSync(password, hash);
}

function changePassword(newPassword) {
  setSetting('admin_password_hash', bcrypt.hashSync(newPassword, 12));
  db.prepare('DELETE FROM sessions').run(); // разлогинить все сессии
}

function createSession(res) {
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = Date.now() + SESSION_DAYS * 864e5;
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
  db.prepare('INSERT INTO sessions (token_hash, expires_at) VALUES (?, ?)').run(sha256(token), expires);
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'strict',
    secure: IS_PROD,
    path: '/',
    maxAge: SESSION_DAYS * 864e5,
  });
}

function readCookie(req, name) {
  const header = req.headers.cookie || '';
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > -1 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return null;
}

function isAuthed(req) {
  const token = readCookie(req, COOKIE);
  if (!token) return false;
  const row = db.prepare('SELECT expires_at FROM sessions WHERE token_hash = ?').get(sha256(token));
  return !!row && row.expires_at > Date.now();
}

function destroySession(req, res) {
  const token = readCookie(req, COOKIE);
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
  res.clearCookie(COOKIE, { path: '/' });
}

function requireAdmin(req, res, next) {
  if (!isAuthed(req)) return res.status(401).json({ error: 'Требуется вход' });
  next();
}

// Защита от CSRF: изменяющие запросы принимаем только с нашего же origin.
function sameOrigin(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  if (origin) {
    let host;
    try { host = new URL(origin).host; } catch { host = null; }
    if (host !== req.headers.host) return res.status(403).json({ error: 'Недопустимый источник запроса' });
  } else if (req.headers['sec-fetch-site'] && req.headers['sec-fetch-site'] !== 'same-origin') {
    return res.status(403).json({ error: 'Недопустимый источник запроса' });
  }
  next();
}

module.exports = { ensureAdminPassword, checkPassword, changePassword, createSession, destroySession, isAuthed, requireAdmin, sameOrigin };
