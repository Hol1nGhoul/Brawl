'use strict';
const crypto = require('crypto');
const express = require('express');
const rateLimit = require('express-rate-limit');
const { db, getSettings } = require('../db');
const { str, int, bool, BadRequest, EMAIL_RE, TG_RE } = require('../validate');
const { yookassaConfigured, createYookassaPayment, fetchYookassaPayment } = require('../payments');
const { notifyAdmin, orderText } = require('../notify');

const router = express.Router();

const PUBLIC_SETTINGS = [
  'store_name', 'hero_kicker', 'hero_title', 'hero_subtitle', 'seller_info',
  'contacts_text', 'offer_text', 'privacy_text', 'info_text', 'delivery_methods',
];

function availablePaymentMethods(settings) {
  return (settings.payment_methods || []).filter((m) => m.type !== 'yookassa' || yookassaConfigured());
}

router.get('/store', (req, res) => {
  const s = getSettings();
  const settings = Object.fromEntries(PUBLIC_SETTINGS.map((k) => [k, s[k]]));
  const categories = db.prepare('SELECT id, name FROM categories WHERE active = 1 ORDER BY sort, id').all();
  const products = db.prepare(`
    SELECT p.id, p.category_id, p.name, p.description, p.price, p.old_price, p.image
    FROM products p LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.active = 1 AND (c.id IS NULL OR c.active = 1)
    ORDER BY p.sort, p.id`).all();
  const payment_methods = availablePaymentMethods(s).map(({ id, name }) => ({ id, name }));
  res.set('Cache-Control', 'no-store');
  res.json({ settings, categories, products, payment_methods });
});

const promoLimiter = rateLimit({ windowMs: 10 * 60e3, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false });
const orderLimiter = rateLimit({ windowMs: 10 * 60e3, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Слишком много заказов подряд. Попробуйте через несколько минут.' } });

function findPromo(code) {
  if (!code) return null;
  const p = db.prepare('SELECT * FROM promo_codes WHERE code = ? AND active = 1').get(code);
  if (!p || (p.max_uses != null && p.used >= p.max_uses)) return null;
  return p;
}

router.post('/promo/check', promoLimiter, (req, res) => {
  const code = str(req.body?.code, 40, { field: 'Промокод' });
  const p = findPromo(code);
  if (!p) return res.status(404).json({ error: 'Промокод не найден или больше не действует' });
  res.json({ code: p.code, percent: p.percent });
});

function newPublicId() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = crypto.randomBytes(10);
  let id = '';
  for (const b of bytes) id += alphabet[b % alphabet.length];
  return id;
}

router.post('/orders', orderLimiter, async (req, res, next) => {
  try {
    const b = req.body || {};
    if (!Array.isArray(b.items) || b.items.length === 0) throw new BadRequest('Корзина пуста');
    if (b.items.length > 50) throw new BadRequest('Слишком много позиций в заказе');
    if (!bool(b.agree)) throw new BadRequest('Нужно принять условия оферты и политику конфиденциальности');

    const telegram = str(b.telegram, 33, { required: true, field: 'Telegram' });
    if (!TG_RE.test(telegram)) throw new BadRequest('Telegram: укажите имя пользователя, например @username');
    const email = str(b.email, 120, { required: true, field: 'Email' });
    if (!EMAIL_RE.test(email)) throw new BadRequest('Email: неверный формат');
    const comment = str(b.comment, 500, { field: 'Комментарий', multiline: true });

    const settings = getSettings();
    const deliveries = settings.delivery_methods || [];
    let delivery = '';
    if (deliveries.length) {
      delivery = str(b.delivery, 100, { field: 'Способ получения' });
      if (!deliveries.some((d) => d.name === delivery)) throw new BadRequest('Выберите способ получения');
    }
    const method = availablePaymentMethods(settings).find((m) => m.id === b.payment);
    if (!method) throw new BadRequest('Выберите способ оплаты');

    // Цены берём только из базы — клиент присылает лишь id и количество.
    const getProduct = db.prepare(`SELECT p.id, p.name, p.price FROM products p
      LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.id = ? AND p.active = 1 AND (c.id IS NULL OR c.active = 1)`);
    const merged = new Map();
    for (const it of b.items) {
      const id = int(it?.id, 1, 2 ** 31, { field: 'Товар' });
      const qty = int(it?.qty, 1, 99, { field: 'Количество' });
      merged.set(id, Math.min(99, (merged.get(id) || 0) + qty));
    }
    const items = [...merged].map(([id, qty]) => {
      const p = getProduct.get(id);
      if (!p) throw new BadRequest('Один из товаров больше не продаётся — обновите страницу');
      return { id: p.id, name: p.name, price: p.price, qty };
    });
    const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);

    const code = str(b.promo, 40, { field: 'Промокод' });
    const promo = code ? findPromo(code) : null;
    if (code && !promo) throw new BadRequest('Промокод не найден или больше не действует');
    const discount = promo ? Math.floor((subtotal * promo.percent) / 100) : 0;
    const total = subtotal - discount;
    if (total < 1) throw new BadRequest('Сумма заказа слишком мала');

    const order = {
      public_id: newPublicId(), items_json: JSON.stringify(items), subtotal, discount, total,
      promo_code: promo ? promo.code : null, contact_telegram: telegram.startsWith('@') ? telegram : '@' + telegram,
      contact_email: email, comment, delivery_method: delivery, payment_method: method.name,
    };

    db.transaction(() => {
      if (promo) {
        const r = db.prepare('UPDATE promo_codes SET used = used + 1 WHERE id = ? AND active = 1 AND (max_uses IS NULL OR used < max_uses)').run(promo.id);
        if (r.changes === 0) throw new BadRequest('Промокод больше не действует');
      }
      db.prepare(`INSERT INTO orders (public_id, items_json, subtotal, discount, total, promo_code,
        contact_telegram, contact_email, comment, delivery_method, payment_method)
        VALUES (@public_id, @items_json, @subtotal, @discount, @total, @promo_code,
        @contact_telegram, @contact_email, @comment, @delivery_method, @payment_method)`).run(order);
    })();

    if (method.type === 'yookassa') {
      try {
        const pay = await createYookassaPayment(order, items);
        db.prepare("UPDATE orders SET payment_id = ?, updated_at = datetime('now') WHERE public_id = ?").run(pay.paymentId, order.public_id);
        notifyAdmin(orderText(order, items, '🛒 Новый заказ (ожидает оплаты ЮKassa)'));
        return res.json({ order_id: order.public_id, total, payment: { type: 'redirect', url: pay.url } });
      } catch (e) {
        console.error(e.message);
        db.prepare("UPDATE orders SET status = 'cancelled', admin_note = 'Ошибка создания платежа', updated_at = datetime('now') WHERE public_id = ?").run(order.public_id);
        if (promo) db.prepare('UPDATE promo_codes SET used = MAX(used - 1, 0) WHERE id = ?').run(promo.id);
        return res.status(502).json({ error: 'Платёжный сервис недоступен. Попробуйте другой способ оплаты или позже.' });
      }
    }

    notifyAdmin(orderText(order, items, '🛒 Новый заказ'));
    res.json({ order_id: order.public_id, total, payment: { type: 'manual', instructions: method.instructions || '' } });
  } catch (e) { next(e); }
});

const STATUS_TEXT = { new: 'Ожидает оплаты', paid: 'Оплачен, выполняется', done: 'Выполнен', cancelled: 'Отменён' };

router.get('/orders/:id', (req, res) => {
  const id = String(req.params.id).slice(0, 20);
  const o = db.prepare('SELECT public_id, items_json, total, status, payment_method, created_at FROM orders WHERE public_id = ?').get(id);
  if (!o) return res.status(404).json({ error: 'Заказ не найден' });
  res.set('Cache-Control', 'no-store');
  res.json({
    order_id: o.public_id, total: o.total, status: o.status, status_text: STATUS_TEXT[o.status] || o.status,
    items: JSON.parse(o.items_json).map(({ name, qty, price }) => ({ name, qty, price })),
    payment_method: o.payment_method, created_at: o.created_at,
  });
});

// Вебхук ЮKassa. Статус проверяем запросом к API, телу уведомления не доверяем.
router.post('/payments/yookassa', async (req, res) => {
  res.sendStatus(200);
  try {
    if (!yookassaConfigured()) return;
    const paymentId = req.body?.object?.id;
    if (typeof paymentId !== 'string' || paymentId.length > 64) return;
    const p = await fetchYookassaPayment(paymentId);
    const order = db.prepare('SELECT * FROM orders WHERE payment_id = ?').get(p.id);
    if (!order || p.metadata?.order_id !== order.public_id) return;
    const paidKop = Math.round(Number(p.amount?.value) * 100);
    if (p.status === 'succeeded' && p.paid && paidKop === order.total * 100 && order.status === 'new') {
      db.prepare("UPDATE orders SET status = 'paid', updated_at = datetime('now') WHERE id = ?").run(order.id);
      notifyAdmin(orderText(order, JSON.parse(order.items_json), '✅ Оплачен заказ'));
    } else if (p.status === 'canceled' && order.status === 'new') {
      db.prepare("UPDATE orders SET status = 'cancelled', admin_note = 'Платёж отменён', updated_at = datetime('now') WHERE id = ?").run(order.id);
    }
  } catch (e) {
    console.error('YooKassa webhook:', e.message);
  }
});

module.exports = router;
