'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const { db, getSettings, setSetting } = require('../db');
const auth = require('../auth');
const { str, int, bool, BadRequest } = require('../validate');
const { upload, saveImage, removeImage } = require('../uploads');
const { yookassaConfigured } = require('../payments');
const cfg = require('../config');

const router = express.Router();
router.use(auth.sameOrigin);
router.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

const loginLimiter = rateLimit({
  windowMs: 15 * 60e3, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Слишком много попыток входа. Подождите 15 минут.' },
});

router.post('/login', loginLimiter, (req, res) => {
  if (!auth.checkPassword(req.body?.password)) return res.status(401).json({ error: 'Неверный пароль' });
  auth.createSession(res);
  res.json({ ok: true });
});

router.post('/logout', (req, res) => { auth.destroySession(req, res); res.json({ ok: true }); });

router.get('/me', (req, res) => res.json({ authed: auth.isAuthed(req) }));

router.use(auth.requireAdmin);

// ---------- Сводка ----------
router.get('/summary', (req, res) => {
  const q = (sql) => db.prepare(sql).get();
  res.json({
    new_orders: q("SELECT COUNT(*) c FROM orders WHERE status = 'new'").c,
    paid_orders: q("SELECT COUNT(*) c FROM orders WHERE status = 'paid'").c,
    revenue_today: q("SELECT COALESCE(SUM(total),0) s FROM orders WHERE status IN ('paid','done') AND date(created_at) = date('now')").s,
    revenue_total: q("SELECT COALESCE(SUM(total),0) s FROM orders WHERE status IN ('paid','done')").s,
    products: q('SELECT COUNT(*) c FROM products').c,
    yookassa: yookassaConfigured(),
    public_url: cfg.PUBLIC_URL,
    telegram: !!(cfg.TELEGRAM_BOT_TOKEN && cfg.TELEGRAM_CHAT_ID),
  });
});

// ---------- Категории ----------
function categoryInput(b) {
  return {
    name: str(b.name, 60, { required: true, field: 'Название' }),
    sort: int(b.sort ?? 0, -9999, 9999, { field: 'Порядок' }),
    active: bool(b.active ?? true) ? 1 : 0,
  };
}

router.get('/categories', (req, res) => {
  res.json(db.prepare(`SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS products
    FROM categories c ORDER BY c.sort, c.id`).all());
});
router.post('/categories', (req, res) => {
  const c = categoryInput(req.body || {});
  const r = db.prepare('INSERT INTO categories (name, sort, active) VALUES (@name, @sort, @active)').run(c);
  res.json({ id: r.lastInsertRowid });
});
router.put('/categories/:id', (req, res) => {
  const c = { ...categoryInput(req.body || {}), id: int(req.params.id, 1, 2 ** 31) };
  const r = db.prepare('UPDATE categories SET name = @name, sort = @sort, active = @active WHERE id = @id').run(c);
  if (!r.changes) return res.status(404).json({ error: 'Не найдено' });
  res.json({ ok: true });
});
router.delete('/categories/:id', (req, res) => {
  db.prepare('DELETE FROM categories WHERE id = ?').run(int(req.params.id, 1, 2 ** 31));
  res.json({ ok: true });
});

// ---------- Товары ----------
function productInput(b) {
  const categoryId = int(b.category_id, 1, 2 ** 31, { field: 'Категория', optional: true });
  if (categoryId && !db.prepare('SELECT 1 FROM categories WHERE id = ?').get(categoryId)) throw new BadRequest('Категория не найдена');
  const price = int(b.price, 1, 10_000_000, { field: 'Цена' });
  const oldPrice = int(b.old_price, 1, 10_000_000, { field: 'Старая цена', optional: true });
  return {
    category_id: categoryId,
    name: str(b.name, 120, { required: true, field: 'Название' }),
    description: str(b.description, 2000, { field: 'Описание', multiline: true }),
    price,
    old_price: oldPrice && oldPrice > price ? oldPrice : null,
    sort: int(b.sort || 0, -9999, 9999, { field: 'Порядок' }),
    active: bool(b.active) ? 1 : 0,
  };
}

router.get('/products', (req, res) => {
  res.json(db.prepare(`SELECT p.*, c.name AS category_name FROM products p
    LEFT JOIN categories c ON c.id = p.category_id ORDER BY c.sort, p.sort, p.id`).all());
});

router.post('/products', upload.single('image'), (req, res) => {
  const p = productInput(req.body || {});
  p.image = saveImage(req.file);
  const r = db.prepare(`INSERT INTO products (category_id, name, description, price, old_price, image, sort, active)
    VALUES (@category_id, @name, @description, @price, @old_price, @image, @sort, @active)`).run(p);
  res.json({ id: r.lastInsertRowid });
});

router.put('/products/:id', upload.single('image'), (req, res) => {
  const id = int(req.params.id, 1, 2 ** 31);
  const existing = db.prepare('SELECT image FROM products WHERE id = ?').get(id);
  if (!existing) return res.status(404).json({ error: 'Не найдено' });
  const p = { ...productInput(req.body || {}), id, image: existing.image };
  const newImage = saveImage(req.file);
  if (newImage || bool(req.body?.remove_image)) {
    removeImage(existing.image);
    p.image = newImage;
  }
  db.prepare(`UPDATE products SET category_id = @category_id, name = @name, description = @description, price = @price,
    old_price = @old_price, image = @image, sort = @sort, active = @active WHERE id = @id`).run(p);
  res.json({ ok: true });
});

router.delete('/products/:id', (req, res) => {
  const id = int(req.params.id, 1, 2 ** 31);
  const p = db.prepare('SELECT image FROM products WHERE id = ?').get(id);
  if (p) {
    db.prepare('DELETE FROM products WHERE id = ?').run(id);
    removeImage(p.image);
  }
  res.json({ ok: true });
});

// ---------- Заказы ----------
const STATUSES = ['new', 'paid', 'done', 'cancelled'];

router.get('/orders', (req, res) => {
  const status = STATUSES.includes(req.query.status) ? req.query.status : null;
  const q = str(req.query.q, 60);
  const page = int(req.query.page || 1, 1, 100000);
  const where = [];
  const params = {};
  if (status) { where.push('status = @status'); params.status = status; }
  if (q) {
    where.push("(public_id LIKE @q ESCAPE '\\' OR contact_telegram LIKE @q ESCAPE '\\' OR contact_email LIKE @q ESCAPE '\\')");
    params.q = `%${q.replace(/[%_\\]/g, '\\$&')}%`;
  }
  const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const total = db.prepare(`SELECT COUNT(*) c FROM orders ${w}`).get(params).c;
  const rows = db.prepare(`SELECT * FROM orders ${w} ORDER BY id DESC LIMIT 50 OFFSET @offset`)
    .all({ ...params, offset: (page - 1) * 50 })
    .map(({ items_json, ...o }) => ({ ...o, items: JSON.parse(items_json) }));
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / 50)), orders: rows });
});

router.put('/orders/:id', (req, res) => {
  const id = int(req.params.id, 1, 2 ** 31);
  const b = req.body || {};
  if (!STATUSES.includes(b.status)) throw new BadRequest('Неверный статус');
  const note = str(b.admin_note, 1000, { field: 'Заметка', multiline: true });
  const r = db.prepare("UPDATE orders SET status = ?, admin_note = ?, updated_at = datetime('now') WHERE id = ?").run(b.status, note, id);
  if (!r.changes) return res.status(404).json({ error: 'Не найдено' });
  res.json({ ok: true });
});

router.delete('/orders/:id', (req, res) => {
  db.prepare('DELETE FROM orders WHERE id = ?').run(int(req.params.id, 1, 2 ** 31));
  res.json({ ok: true });
});

// ---------- Промокоды ----------
function promoInput(b) {
  const code = str(b.code, 40, { required: true, field: 'Код' });
  if (!/^[A-Za-z0-9_-]+$/.test(code)) throw new BadRequest('Код: только латиница, цифры, «-» и «_»');
  return {
    code,
    percent: int(b.percent, 1, 95, { field: 'Скидка, %' }),
    max_uses: int(b.max_uses, 1, 1_000_000, { field: 'Лимит использований', optional: true }),
    active: bool(b.active ?? true) ? 1 : 0,
  };
}
router.get('/promos', (req, res) => res.json(db.prepare('SELECT * FROM promo_codes ORDER BY id DESC').all()));
router.post('/promos', (req, res) => {
  try {
    const r = db.prepare('INSERT INTO promo_codes (code, percent, max_uses, active) VALUES (@code, @percent, @max_uses, @active)').run(promoInput(req.body || {}));
    res.json({ id: r.lastInsertRowid });
  } catch (e) {
    if (String(e.code).startsWith('SQLITE_CONSTRAINT')) throw new BadRequest('Такой промокод уже есть');
    throw e;
  }
});
router.put('/promos/:id', (req, res) => {
  const p = { ...promoInput(req.body || {}), id: int(req.params.id, 1, 2 ** 31) };
  try {
    db.prepare('UPDATE promo_codes SET code = @code, percent = @percent, max_uses = @max_uses, active = @active WHERE id = @id').run(p);
  } catch (e) {
    if (String(e.code).startsWith('SQLITE_CONSTRAINT')) throw new BadRequest('Такой промокод уже есть');
    throw e;
  }
  res.json({ ok: true });
});
router.delete('/promos/:id', (req, res) => {
  db.prepare('DELETE FROM promo_codes WHERE id = ?').run(int(req.params.id, 1, 2 ** 31));
  res.json({ ok: true });
});

// ---------- Настройки ----------
const TEXT_SETTINGS = {
  store_name: [40, false], hero_kicker: [60, false], hero_title: [120, false], hero_subtitle: [300, true],
  seller_info: [300, true], contacts_text: [3000, true], offer_text: [50000, true],
  privacy_text: [50000, true], info_text: [20000, true],
};

router.get('/settings', (req, res) => {
  const { admin_password_hash, ...s } = getSettings();
  res.json(s);
});

router.put('/settings', (req, res) => {
  const b = req.body || {};
  const updates = {};
  for (const [key, [max, multiline]] of Object.entries(TEXT_SETTINGS)) {
    if (key in b) updates[key] = str(b[key], max, { field: key, multiline, required: key === 'store_name' });
  }
  if ('delivery_methods' in b) {
    if (!Array.isArray(b.delivery_methods) || b.delivery_methods.length > 10) throw new BadRequest('Способы получения: до 10 штук');
    updates.delivery_methods = b.delivery_methods.map((d) => ({
      name: str(d?.name, 60, { required: true, field: 'Способ получения' }),
      description: str(d?.description, 200, { field: 'Описание способа получения' }),
    }));
  }
  if ('payment_methods' in b) {
    if (!Array.isArray(b.payment_methods) || b.payment_methods.length > 15) throw new BadRequest('Способы оплаты: до 15 штук');
    const ids = new Set();
    updates.payment_methods = b.payment_methods.map((m) => {
      const id = str(m?.id, 32, { required: true, field: 'ID способа оплаты' });
      if (!/^[a-z0-9_-]+$/.test(id) || ids.has(id)) throw new BadRequest(`ID способа оплаты «${id}»: латиница/цифры, без повторов`);
      ids.add(id);
      if (!['manual', 'yookassa'].includes(m?.type)) throw new BadRequest('Тип способа оплаты: manual или yookassa');
      return {
        id, type: m.type,
        name: str(m?.name, 60, { required: true, field: 'Название способа оплаты' }),
        instructions: str(m?.instructions, 2000, { field: 'Инструкция по оплате', multiline: true }),
      };
    });
  }
  db.transaction(() => { for (const [k, v] of Object.entries(updates)) setSetting(k, v); })();
  res.json({ ok: true });
});

router.post('/password', (req, res) => {
  const b = req.body || {};
  if (!auth.checkPassword(b.current)) throw new BadRequest('Текущий пароль неверен');
  const next = String(b.next || '');
  if (next.length < 10 || next.length > 200) throw new BadRequest('Новый пароль: от 10 символов');
  auth.changePassword(next);
  auth.createSession(res);
  res.json({ ok: true });
});

module.exports = router;
