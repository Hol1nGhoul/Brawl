'use strict';
const crypto = require('crypto');
const cfg = require('./config');

const API = 'https://api.yookassa.ru/v3';

function yookassaConfigured() {
  return !!(cfg.YOOKASSA_SHOP_ID && cfg.YOOKASSA_SECRET_KEY);
}

function authHeader() {
  return 'Basic ' + Buffer.from(`${cfg.YOOKASSA_SHOP_ID}:${cfg.YOOKASSA_SECRET_KEY}`).toString('base64');
}

const money = (kopecks) => (kopecks / 100).toFixed(2);

// Распределяем скидку по позициям пропорционально (для чека 54-ФЗ).
function receiptItems(items, totalRub) {
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0) * 100;
  const target = totalRub * 100;
  let left = target;
  return items.map((it, idx) => {
    const line = it.price * it.qty * 100;
    let amount = idx === items.length - 1 ? left : Math.round((line * target) / subtotal);
    left -= amount;
    // Цена за единицу: делим поровну; остаток копеек — нет смысла дробить, поэтому
    // при неделимой сумме передаём позицию одной строкой с quantity=1.
    const evenly = amount % it.qty === 0;
    return {
      description: (evenly ? it.name : `${it.name} ×${it.qty}`).slice(0, 128),
      quantity: evenly ? String(it.qty) : '1',
      amount: { value: money(evenly ? amount / it.qty : amount), currency: 'RUB' },
      vat_code: cfg.YOOKASSA_VAT_CODE,
      payment_mode: 'full_payment',
      payment_subject: 'service',
    };
  });
}

async function createYookassaPayment(order, items) {
  const returnUrl = `${cfg.PUBLIC_URL}/?order=${encodeURIComponent(order.public_id)}`;
  const body = {
    amount: { value: money(order.total * 100), currency: 'RUB' },
    capture: true,
    confirmation: { type: 'redirect', return_url: returnUrl },
    description: `Заказ ${order.public_id}`.slice(0, 128),
    metadata: { order_id: order.public_id },
  };
  if (cfg.YOOKASSA_RECEIPT) {
    body.receipt = { customer: { email: order.contact_email }, items: receiptItems(items, order.total) };
  }
  const r = await fetch(`${API}/payments`, {
    method: 'POST',
    headers: {
      Authorization: authHeader(),
      'Content-Type': 'application/json',
      'Idempotence-Key': crypto.randomUUID(),
    },
    body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.confirmation?.confirmation_url) {
    throw new Error(`ЮKassa: ${r.status} ${data.description || ''}`.trim());
  }
  return { paymentId: data.id, url: data.confirmation.confirmation_url };
}

// Не доверяем телу вебхука — запрашиваем статус платежа у ЮKassa напрямую.
async function fetchYookassaPayment(paymentId) {
  const r = await fetch(`${API}/payments/${encodeURIComponent(paymentId)}`, {
    headers: { Authorization: authHeader() },
  });
  if (!r.ok) throw new Error(`ЮKassa: ${r.status}`);
  return r.json();
}

module.exports = { yookassaConfigured, createYookassaPayment, fetchYookassaPayment, receiptItems };
