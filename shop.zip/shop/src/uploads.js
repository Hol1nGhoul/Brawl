'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { UPLOAD_DIR } = require('./config');
const { BadRequest } = require('./validate');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 3 * 1024 * 1024, files: 1, fields: 30 },
});

// Тип файла определяем по содержимому, а не по имени/заголовку. SVG не принимаем (XSS).
function detectImage(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0x89 && buf.toString('ascii', 1, 4) === 'PNG') return 'png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  if (buf.toString('ascii', 0, 4) === 'GIF8') return 'gif';
  return null;
}

function saveImage(file) {
  if (!file) return null;
  const ext = detectImage(file.buffer);
  if (!ext) throw new BadRequest('Картинка: допустимы только PNG, JPG, WEBP или GIF');
  const name = `${crypto.randomBytes(12).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), file.buffer);
  return name;
}

function removeImage(name) {
  if (!name || !/^[a-f0-9]{24}\.(png|jpg|webp|gif)$/.test(name)) return;
  fs.rm(path.join(UPLOAD_DIR, name), { force: true }, () => {});
}

module.exports = { upload, saveImage, removeImage };
