'use strict';
const { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID } = require('./config');

// Уведомление администратору в Telegram (если заданы токен бота и chat id).
async function notifyAdmin(text) {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) return;
  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: text.slice(0, 4000), disable_web_page_preview: true }),
    });
  } catch (e) {
    console.error('Telegram notify failed:', e.message);
  }
}

function orderText(order, items, title) {
  const lines = items.map((i) => `• ${i.name} × ${i.qty} = ${i.price * i.qty} ₽`);
  return [
    `${title} ${order.public_id}`,
    ...lines,
    order.discount ? `Скидка: −${order.discount} ₽ (${order.promo_code})` : null,
    `Итого: ${order.total} ₽`,
    `Telegram: ${order.contact_telegram || '—'}`,
    `Email: ${order.contact_email || '—'}`,
    order.delivery_method ? `Получение: ${order.delivery_method}` : null,
    `Оплата: ${order.payment_method}`,
    order.comment ? `Комментарий: ${order.comment}` : null,
  ].filter(Boolean).join('\n');
}

module.exports = { notifyAdmin, orderText };
