'use strict';
const path = require('path');

// Подхватываем .env, если он есть (Node 20.12+ / 22+).
try { process.loadEnvFile(path.join(__dirname, '..', '.env')); } catch { /* .env необязателен */ }

const env = process.env;
const DATA_DIR = path.resolve(env.DATA_DIR || path.join(__dirname, '..', 'data'));

module.exports = {
  PORT: Number(env.PORT) || 3000,
  HOST: env.HOST || '0.0.0.0',
  NODE_ENV: env.NODE_ENV || 'development',
  IS_PROD: env.NODE_ENV === 'production',
  // Публичный адрес сайта, например https://myshop.ru — нужен для возврата после оплаты.
  PUBLIC_URL: (env.PUBLIC_URL || '').replace(/\/+$/, ''),
  // Сколько обратных прокси стоит перед приложением (nginx, Cloudflare и т.п.).
  TRUST_PROXY: env.TRUST_PROXY ? Number(env.TRUST_PROXY) : 0,
  DATA_DIR,
  UPLOAD_DIR: path.join(DATA_DIR, 'uploads'),
  ADMIN_PASSWORD: env.ADMIN_PASSWORD || '',
  SESSION_DAYS: Number(env.SESSION_DAYS) || 7,

  TELEGRAM_BOT_TOKEN: env.TELEGRAM_BOT_TOKEN || '',
  TELEGRAM_CHAT_ID: env.TELEGRAM_CHAT_ID || '',

  YOOKASSA_SHOP_ID: env.YOOKASSA_SHOP_ID || '',
  YOOKASSA_SECRET_KEY: env.YOOKASSA_SECRET_KEY || '',
  // 1 — передавать чек (54-ФЗ) в ЮKassa. Нужен, если вы используете их фискализацию.
  YOOKASSA_RECEIPT: env.YOOKASSA_RECEIPT === '1',
  YOOKASSA_VAT_CODE: Number(env.YOOKASSA_VAT_CODE) || 1,
};
