'use strict';
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const fmt = (n) => new Intl.NumberFormat('ru-RU').format(n) + ' ₽';

  // Мини-хелпер для создания DOM без innerHTML (защита от XSS).
  function h(tag, props = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style') el.style.cssText = v; // CSSOM не блокируется CSP
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k in el && typeof v !== 'string') el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) if (c != null && c !== false) el.append(c instanceof Node ? c : String(c));
    return el;
  }

  // Безопасно превращаем ссылки в тексте в <a>.
  function richText(text) {
    const box = h('div', { class: 'prose' });
    const re = /(https?:\/\/[^\s<>"]+|@[A-Za-z0-9_]{4,32})/g;
    let last = 0;
    for (const m of String(text || '').matchAll(re)) {
      box.append(text.slice(last, m.index));
      const t = m[0].replace(/[.,;:!?)]+$/, '');
      const href = t.startsWith('@') ? `https://t.me/${t.slice(1)}` : t;
      box.append(h('a', { href, target: '_blank', rel: 'noopener noreferrer nofollow' }, t));
      last = m.index + t.length;
    }
    box.append(String(text || '').slice(last));
    return box;
  }

  const storage = {
    get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* приватный режим */ } },
  };

  async function api(path, opts = {}) {
    const r = await fetch('/api' + path, {
      ...opts,
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'Ошибка сети, попробуйте ещё раз');
    return data;
  }

  const state = {
    store: null,
    products: new Map(),
    category: 'all',
    cart: storage.get('cart', {}), // { productId: qty }
    promo: null, // { code, percent }
  };

  function toast(msg) {
    document.querySelectorAll('.toast').forEach((t) => t.remove());
    const t = h('div', { class: 'toast', role: 'status' }, msg);
    document.body.append(t);
    setTimeout(() => t.remove(), 2400);
  }

  // ---------- Рендер витрины ----------
  function renderShell() {
    const s = state.store.settings;
    document.title = s.store_name;
    $('#logo').textContent = s.store_name;
    $('#heroKicker').textContent = s.hero_kicker || '';
    $('#heroTitle').textContent = s.hero_title || '';
    $('#heroSub').textContent = s.hero_subtitle || '';
    $('#copy').textContent = `© ${new Date().getFullYear()} ${s.store_name}`;
    $('#sellerInfo').textContent = s.seller_info || '';
  }

  function renderTabs() {
    const tabs = $('#tabs');
    // Показываем только категории, в которых есть товары; вкладка «Все» — первой.
    const cats = state.store.categories.filter((c) => state.store.products.some((p) => p.category_id === c.id));
    const list = cats.length ? [{ id: 'all', name: 'Все' }, ...cats] : [];
    tabs.hidden = list.length === 0;
    tabs.replaceChildren(...list.map((c) =>
      h('button', {
        class: 'tab', type: 'button', role: 'tab', 'aria-selected': String(state.category === c.id),
        onclick: () => { state.category = c.id; renderTabs(); renderGrid(); },
      }, c.name)));
  }

  function productImage(p, cls) {
    return p.image
      ? h('img', { src: '/uploads/' + p.image, alt: p.name, loading: 'lazy', decoding: 'async', class: cls })
      : h('span', { class: 'card__ph', 'aria-hidden': 'true' }, (p.name || '?').trim().charAt(0).toUpperCase());
  }

  function cartControl(p) {
    const qty = state.cart[p.id] || 0;
    if (!qty) {
      return h('button', { class: 'btn btn--primary btn--block', type: 'button', onclick: () => addToCart(p.id) }, 'В корзину');
    }
    return h('div', { class: 'stepper' },
      h('button', { type: 'button', 'aria-label': 'Меньше', onclick: () => setQty(p.id, qty - 1) }, '−'),
      h('span', {}, qty),
      h('button', { type: 'button', 'aria-label': 'Больше', onclick: () => setQty(p.id, qty + 1) }, '+'));
  }

  function renderGrid() {
    const grid = $('#grid');
    const items = state.store.products.filter((p) => state.category === 'all' || p.category_id === state.category);
    if (!items.length) {
      grid.replaceChildren(h('p', { class: 'empty' }, 'Здесь пока нет товаров'));
      return;
    }
    grid.replaceChildren(...items.map((p) => h('article', { class: 'card' },
      h('button', { class: 'card__media', type: 'button', 'aria-label': 'Подробнее: ' + p.name, onclick: () => openProduct(p) },
        productImage(p)),
      h('h3', { class: 'card__name', title: p.name }, p.name),
      h('div', { class: 'card__price' },
        h('span', { class: 'price' }, fmt(p.price)),
        p.old_price ? h('span', { class: 'old-price' }, fmt(p.old_price)) : null),
      h('div', { class: 'card__actions', 'data-actions': p.id }, cartControl(p)))));
  }

  function refreshCardControls() {
    document.querySelectorAll('[data-actions]').forEach((box) => {
      const p = state.products.get(Number(box.dataset.actions));
      if (p) box.replaceChildren(cartControl(p));
    });
  }

  // ---------- Корзина ----------
  function cartLines() {
    return Object.entries(state.cart)
      .map(([id, qty]) => ({ p: state.products.get(Number(id)), qty }))
      .filter((l) => l.p && l.qty > 0);
  }

  function saveCart() {
    // Убираем товары, которых больше нет в каталоге.
    for (const id of Object.keys(state.cart)) if (!state.products.has(Number(id))) delete state.cart[id];
    storage.set('cart', state.cart);
    const count = cartLines().reduce((s, l) => s + l.qty, 0);
    const badge = $('#cartCount');
    badge.textContent = count;
    badge.hidden = count === 0;
  }

  function addToCart(id) {
    setQty(id, (state.cart[id] || 0) + 1);
    const btn = $('#cartBtn');
    btn.classList.remove('bump'); void btn.offsetWidth; btn.classList.add('bump');
    toast('Добавлено в корзину');
  }

  function setQty(id, qty) {
    qty = Math.max(0, Math.min(99, qty));
    if (qty === 0) delete state.cart[id]; else state.cart[id] = qty;
    saveCart();
    refreshCardControls();
    if (!$('#cartOverlay').hidden) renderCart();
  }

  function totals() {
    const sum = cartLines().reduce((s, l) => s + l.p.price * l.qty, 0);
    const discount = state.promo ? Math.floor((sum * state.promo.percent) / 100) : 0;
    return { sum, discount, total: sum - discount };
  }

  function renderCart() {
    const lines = cartLines();
    const box = $('#cartItems');
    $('#checkout').hidden = lines.length === 0;
    if (!lines.length) {
      box.replaceChildren(h('div', { class: 'cart-empty' },
        h('p', {}, 'Корзина пуста'),
        h('button', { class: 'btn btn--ghost', type: 'button', onclick: closeCart }, 'Перейти к товарам')));
      return;
    }
    box.replaceChildren(...lines.map(({ p, qty }) => h('div', { class: 'line' },
      h('div', { class: 'line__img' }, productImage(p)),
      h('div', {},
        h('div', { class: 'line__name' }, p.name),
        h('div', { class: 'line__price' }, `${fmt(p.price)} × ${qty} = ${fmt(p.price * qty)}`)),
      h('div', { class: 'stepper stepper--sm' },
        h('button', { type: 'button', 'aria-label': 'Меньше', onclick: () => setQty(p.id, qty - 1) }, '−'),
        h('span', {}, qty),
        h('button', { type: 'button', 'aria-label': 'Больше', onclick: () => setQty(p.id, qty + 1) }, '+')))));
    const t = totals();
    $('#sumItems').textContent = fmt(t.sum);
    $('#discountRow').hidden = !t.discount;
    $('#sumDiscount').textContent = '−' + fmt(t.discount);
    $('#sumTotal').textContent = fmt(t.total);
    $('#payBtn').textContent = 'Оплатить ' + fmt(t.total);
  }

  function renderCheckoutOptions() {
    const { settings, payment_methods } = state.store;
    const deliveries = settings.delivery_methods || [];
    $('#deliveryBox').hidden = deliveries.length === 0;
    $('#deliveryList').replaceChildren(...deliveries.map((d, i) => h('label', { class: 'choice' },
      h('input', { type: 'radio', name: 'delivery', value: d.name, checked: i === 0 }),
      h('span', {}, h('b', {}, d.name), d.description ? h('small', {}, d.description) : null))));
    $('#paymentList').replaceChildren(...payment_methods.map((m, i) => h('label', { class: 'choice' },
      h('input', { type: 'radio', name: 'payment', value: m.id, checked: i === 0 }),
      h('span', {}, h('b', {}, m.name)))));
    if (!payment_methods.length) $('#paymentList').append(h('p', { class: 'hint bad' }, 'Способы оплаты пока не настроены'));
  }

  let lastFocus = null;
  function openCart() {
    lastFocus = document.activeElement;
    renderCart();
    $('#cartOverlay').hidden = false;
    document.body.style.overflow = 'hidden';
    $('#cartOverlay [data-close]').focus();
  }
  function closeCart() {
    $('#cartOverlay').hidden = true;
    document.body.style.overflow = '';
    lastFocus?.focus?.();
  }

  // ---------- Модалка ----------
  function openModal(title, body) {
    if ($('#modal').hidden) lastFocus = document.activeElement;
    $('#modalTitle').textContent = title;
    $('#modalBody').replaceChildren(body);
    $('#modal').hidden = false;
    document.body.style.overflow = 'hidden';
    $('#modal [data-close]').focus();
  }
  function closeModal() {
    $('#modal').hidden = true;
    if ($('#cartOverlay').hidden) document.body.style.overflow = '';
    lastFocus?.focus?.();
  }

  const INFO_TITLES = { offer_text: 'Публичная оферта', privacy_text: 'Политика конфиденциальности', contacts_text: 'Контакты', info_text: 'Как получить заказ' };
  function openInfo(key) {
    openModal(INFO_TITLES[key] || '', richText(state.store?.settings?.[key] || 'Раздел не заполнен'));
  }

  function openProduct(p) {
    openModal(p.name, h('div', { class: 'pview' },
      h('div', { class: 'pview__img' }, productImage(p)),
      h('div', {},
        h('div', { class: 'card__price' },
          h('span', { class: 'price' }, fmt(p.price)),
          p.old_price ? h('span', { class: 'old-price' }, fmt(p.old_price)) : null),
        p.description ? richText(p.description) : h('p', { class: 'muted' }, 'Описание не добавлено'),
        h('button', { class: 'btn btn--primary', type: 'button', onclick: () => { addToCart(p.id); closeModal(); } }, 'Добавить в корзину'))));
  }

  // ---------- Промокод ----------
  async function applyPromo() {
    const code = $('#promoInput').value.trim();
    const msg = $('#promoMsg');
    msg.className = 'hint';
    if (!code) { state.promo = null; msg.textContent = ''; renderCart(); return; }
    try {
      state.promo = await api('/promo/check', { method: 'POST', body: { code } });
      msg.textContent = `Промокод применён: −${state.promo.percent}%`;
      msg.classList.add('ok');
    } catch (e) {
      state.promo = null;
      msg.textContent = e.message;
      msg.classList.add('bad');
    }
    renderCart();
  }

  // ---------- Оформление ----------
  async function submitOrder(e) {
    e.preventDefault();
    const form = e.target;
    const err = $('#orderError');
    err.textContent = '';
    const fd = new FormData(form);
    const telegram = String(fd.get('telegram') || '').trim();
    const email = String(fd.get('email') || '').trim();
    if (!/^@?[A-Za-z0-9_]{4,32}$/.test(telegram)) { err.textContent = 'Укажите Telegram в формате @username'; form.telegram.focus(); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { err.textContent = 'Укажите корректный e-mail'; form.email.focus(); return; }
    if (!fd.get('payment')) { err.textContent = 'Выберите способ оплаты'; return; }
    if (!form.agree.checked) { err.textContent = 'Нужно принять условия оферты и политику'; return; }

    storage.set('contacts', { telegram, email });
    const btn = $('#payBtn');
    btn.disabled = true;
    btn.textContent = 'Оформляем…';
    try {
      const res = await api('/orders', {
        method: 'POST',
        body: {
          items: cartLines().map((l) => ({ id: l.p.id, qty: l.qty })),
          promo: state.promo?.code || '', telegram, email,
          comment: String(fd.get('comment') || ''), delivery: fd.get('delivery') || '',
          payment: fd.get('payment'), agree: true,
        },
      });
      rememberOrder(res.order_id);
      state.cart = {}; state.promo = null; $('#promoInput').value = ''; $('#promoMsg').textContent = '';
      saveCart(); refreshCardControls();
      if (res.payment.type === 'redirect') { location.href = res.payment.url; return; }
      closeCart();
      showOrderCreated(res);
    } catch (e2) {
      err.textContent = e2.message;
    } finally {
      btn.disabled = false;
      renderCart();
    }
  }

  function rememberOrder(id) {
    const list = storage.get('orders', []).filter((x) => x !== id);
    storage.set('orders', [id, ...list].slice(0, 10));
  }

  function showOrderCreated(res) {
    openModal('Заказ оформлен', h('div', { class: 'order-box' },
      h('p', { class: 'muted' }, 'Номер вашего заказа'),
      h('div', { class: 'order-id' }, res.order_id),
      h('p', {}, 'Сумма к оплате: ', h('b', {}, fmt(res.total))),
      res.payment.instructions ? h('div', { class: 'instr' }, h('b', {}, 'Как оплатить'), richText(res.payment.instructions)) : null,
      h('p', { class: 'muted' }, 'Сохраните номер заказа. Мы свяжемся с вами в Telegram.')));
  }

  async function showOrderStatus(id) {
    try {
      const o = await api('/orders/' + encodeURIComponent(id));
      openModal('Заказ ' + o.order_id, h('div', { class: 'order-box' },
        h('span', { class: 'status status--' + o.status }, o.status_text),
        h('div', { class: 'order-id' }, o.order_id),
        h('div', { class: 'instr' }, ...o.items.map((i) => h('div', {}, `${i.name} × ${i.qty}`)), h('b', {}, 'Итого: ' + fmt(o.total)))));
    } catch (e) { toast(e.message); }
  }

  // ---------- Старт ----------
  async function init() {
    document.addEventListener('click', (e) => {
      const info = e.target.closest('[data-info]');
      if (info) { e.preventDefault(); openInfo(info.dataset.info); return; }
      if (e.target.closest('[data-close]')) { e.target.closest('#modal') ? closeModal() : closeCart(); return; }
      if (e.target.id === 'modal') closeModal();
      if (e.target.id === 'cartOverlay') closeCart();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      if (!$('#modal').hidden) closeModal(); else if (!$('#cartOverlay').hidden) closeCart();
    });
    $('#cartBtn').addEventListener('click', openCart);
    $('#promoBtn').addEventListener('click', applyPromo);
    $('#promoInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); applyPromo(); } });
    $('#orderForm').addEventListener('submit', submitOrder);
    const saved = storage.get('contacts', {});
    if (saved.telegram) $('#orderForm').telegram.value = saved.telegram;
    if (saved.email) $('#orderForm').email.value = saved.email;

    try {
      state.store = await api('/store');
    } catch (e) {
      $('#grid').replaceChildren(h('p', { class: 'empty' }, 'Не удалось загрузить каталог. Обновите страницу.'));
      return;
    }
    state.store.products.forEach((p) => state.products.set(p.id, p));
    renderShell(); renderTabs(); renderGrid(); renderCheckoutOptions(); saveCart();

    const orderId = new URLSearchParams(location.search).get('order');
    if (orderId) {
      history.replaceState(null, '', location.pathname);
      showOrderStatus(orderId);
    }
  }

  init();
})();
