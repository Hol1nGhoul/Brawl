'use strict';
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const fmt = (n) => new Intl.NumberFormat('ru-RU').format(n) + ' ₽';
  const STATUS = { new: 'Новый', paid: 'Оплачен', done: 'Выполнен', cancelled: 'Отменён' };

  function h(tag, props = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style') el.style.cssText = v; // CSSOM не блокируется CSP
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k in el && typeof v !== 'string') el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) if (c != null && c !== false) el.append(c instanceof Node ? c : String(c));
    return el;
  }

  async function api(path, { method = 'GET', body, form } = {}) {
    const opts = { method, headers: {} };
    if (form) opts.body = form;
    else if (body !== undefined) { opts.body = JSON.stringify(body); opts.headers['Content-Type'] = 'application/json'; }
    const r = await fetch('/api/admin' + path, opts);
    const data = await r.json().catch(() => ({}));
    if (r.status === 401 && path !== '/login') { showLogin(); throw new Error('Сессия истекла, войдите снова'); }
    if (!r.ok) throw new Error(data.error || 'Ошибка запроса');
    return data;
  }

  function toast(msg, bad = false) {
    document.querySelectorAll('.toast').forEach((t) => t.remove());
    const t = h('div', { class: 'toast', role: 'status', style: bad ? 'background:#ff5d6c;color:#fff' : null }, msg);
    document.body.append(t);
    setTimeout(() => t.remove(), 2600);
  }
  const fail = (e) => toast(e.message, true);

  // ---------- Модалка ----------
  function openModal(title, body) {
    $('#modalTitle').textContent = title;
    $('#modalBody').replaceChildren(body);
    $('#modal').hidden = false;
  }
  const closeModal = () => { $('#modal').hidden = true; };
  $('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal' || e.target.closest('[data-close]')) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  // ---------- Вход ----------
  function showLogin() { $('#appView').hidden = true; $('#loginView').hidden = false; }
  function showApp() { $('#loginView').hidden = true; $('#appView').hidden = false; go(current); }

  $('#loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#loginError').textContent = '';
    try {
      await api('/login', { method: 'POST', body: { password: e.target.password.value } });
      e.target.reset();
      showApp();
    } catch (err) { $('#loginError').textContent = err.message; }
  });
  $('#logoutBtn').addEventListener('click', async () => { await api('/logout', { method: 'POST' }).catch(() => {}); showLogin(); });

  // ---------- Навигация ----------
  let current = 'orders';
  const views = { orders: viewOrders, products: viewProducts, categories: viewCategories, promos: viewPromos, settings: viewSettings };
  $('#atabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (b) go(b.dataset.tab);
  });
  function go(tab) {
    current = tab;
    document.querySelectorAll('#atabs [data-tab]').forEach((b) => b.classList.toggle('is-active', b.dataset.tab === tab));
    loadSummary();
    $('#view').replaceChildren(h('p', { class: 'muted' }, 'Загрузка…'));
    views[tab]().catch(fail);
  }

  async function loadSummary() {
    try {
      const s = await api('/summary');
      const settings = await api('/settings');
      const badge = $('#newBadge');
      badge.textContent = s.new_orders; badge.hidden = !s.new_orders;
      const warns = [];
      const docs = ['offer_text', 'privacy_text', 'contacts_text', 'seller_info'].some((k) => /\[[^\]]+\]/.test(settings[k] || ''));
      if (docs) warns.push('В документах остались шаблонные поля в [квадратных скобках] — заполните реквизиты в «Настройках» перед запуском.');
      if ((settings.payment_methods || []).some((m) => m.type === 'yookassa') && !s.yookassa) warns.push('Способ оплаты ЮKassa добавлен, но ключи YOOKASSA_SHOP_ID / YOOKASSA_SECRET_KEY не заданы — покупатели его не увидят.');
      if (s.yookassa && !s.public_url) warns.push('Не задан PUBLIC_URL — после оплаты в ЮKassa покупатель не сможет вернуться на сайт.');
      $('#summary').replaceChildren(
        ...warns.map((w) => h('div', { class: 'warn', style: 'grid-column:1/-1' }, '⚠ ' + w)),
        stat('Новые заказы', s.new_orders), stat('Оплачены, ждут выдачи', s.paid_orders),
        stat('Выручка сегодня', fmt(s.revenue_today)), stat('Выручка всего', fmt(s.revenue_total)),
        stat('Telegram-уведомления', s.telegram ? 'включены' : 'выключены'));
    } catch { /* не критично */ }
  }
  const stat = (label, value) => h('div', { class: 'stat' }, h('small', {}, label), h('b', {}, value));

  function table(headers, rows, emptyText) {
    return h('div', { class: 'panel' }, h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, headers.map((x) => h('th', { class: x.cls }, x.label ?? x)))),
      h('tbody', {}, rows.length ? rows : h('tr', {}, h('td', { class: 'empty-row', colspan: headers.length }, emptyText))))));
  }

  const confirmDo = (text, fn) => { if (window.confirm(text)) fn().catch(fail); };

  // ================= ЗАКАЗЫ =================
  const orderFilter = { status: '', q: '', page: 1 };
  async function viewOrders() {
    const params = new URLSearchParams({ page: orderFilter.page });
    if (orderFilter.status) params.set('status', orderFilter.status);
    if (orderFilter.q) params.set('q', orderFilter.q);
    const data = await api('/orders?' + params);
    const search = h('input', { type: 'text', placeholder: 'Поиск: номер, Telegram, e-mail', value: orderFilter.q });
    let timer;
    search.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { orderFilter.q = search.value.trim(); orderFilter.page = 1; viewOrders().catch(fail); }, 350); });
    const status = h('select', { onchange: (e) => { orderFilter.status = e.target.value; orderFilter.page = 1; viewOrders().catch(fail); } },
      h('option', { value: '' }, 'Все статусы'),
      Object.entries(STATUS).map(([k, v]) => h('option', { value: k, selected: orderFilter.status === k }, v)));

    const rows = data.orders.map((o) => h('tr', {},
      h('td', { class: 'mono' }, o.public_id),
      h('td', { class: 'num hide-sm' }, o.created_at.slice(0, 16)),
      h('td', {}, o.items.map((i) => `${i.name} ×${i.qty}`).join(', ')),
      h('td', { class: 'num' }, fmt(o.total)),
      h('td', { class: 'hide-sm' }, o.contact_telegram),
      h('td', {}, h('span', { class: 'pill pill--' + o.status }, STATUS[o.status] || o.status)),
      h('td', {}, h('div', { class: 'row-actions' }, h('button', { class: 'btn btn--ghost btn--sm', type: 'button', onclick: () => openOrder(o) }, 'Открыть')))));

    const pager = data.pages > 1 ? h('div', { class: 'pager' },
      h('button', { class: 'btn btn--ghost btn--sm', disabled: data.page <= 1, onclick: () => { orderFilter.page--; viewOrders().catch(fail); } }, '←'),
      h('span', { class: 'muted' }, `${data.page} / ${data.pages}`),
      h('button', { class: 'btn btn--ghost btn--sm', disabled: data.page >= data.pages, onclick: () => { orderFilter.page++; viewOrders().catch(fail); } }, '→')) : null;

    const hadFocus = document.activeElement?.placeholder === search.placeholder;
    $('#view').replaceChildren(
      h('div', { class: 'toolbar' }, search, status),
      table(['№', { label: 'Дата', cls: 'hide-sm' }, 'Товары', 'Сумма', { label: 'Telegram', cls: 'hide-sm' }, 'Статус', ''], rows, 'Заказов пока нет'),
      pager || "");
    if (hadFocus) { search.focus(); search.setSelectionRange(search.value.length, search.value.length); }
  }

  function openOrder(o) {
    const status = h('select', {}, Object.entries(STATUS).map(([k, v]) => h('option', { value: k, selected: o.status === k }, v)));
    const note = h('textarea', { rows: 3, maxlength: 1000 }, o.admin_note || '');
    const dl = (pairs) => h('dl', { class: 'kv' }, pairs.filter(([, v]) => v).flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, v)]));
    openModal('Заказ ' + o.public_id, h('div', {},
      dl([
        ['Дата', o.created_at + ' (UTC)'],
        ['Товары', h('ul', { class: 'order-items' }, o.items.map((i) => h('li', {}, `${i.name} × ${i.qty} — ${fmt(i.price * i.qty)}`)))],
        ['Сумма товаров', fmt(o.subtotal)],
        ['Скидка', o.discount ? `−${fmt(o.discount)} (${o.promo_code})` : ''],
        ['Итого', h('b', {}, fmt(o.total))],
        ['Telegram', o.contact_telegram ? h('a', { href: 'https://t.me/' + o.contact_telegram.replace(/^@/, ''), target: '_blank', rel: 'noopener noreferrer' }, o.contact_telegram) : ''],
        ['E-mail', o.contact_email],
        ['Получение', o.delivery_method],
        ['Оплата', o.payment_method],
        ['ID платежа', o.payment_id],
        ['Комментарий', o.comment],
      ]),
      h('label', { class: 'field' }, h('span', {}, 'Статус'), status),
      h('label', { class: 'field' }, h('span', {}, 'Заметка (видна только вам)'), note),
      h('div', { class: 'form-actions' },
        h('button', { class: 'btn btn--danger', type: 'button', onclick: () => confirmDo('Удалить заказ безвозвратно?', async () => {
          await api('/orders/' + o.id, { method: 'DELETE' }); closeModal(); toast('Заказ удалён'); go('orders');
        }) }, 'Удалить'),
        h('button', { class: 'btn btn--primary', type: 'button', onclick: async () => {
          try {
            await api('/orders/' + o.id, { method: 'PUT', body: { status: status.value, admin_note: note.value } });
            closeModal(); toast('Сохранено'); go('orders');
          } catch (e) { fail(e); }
        } }, 'Сохранить'))));
  }

  // ================= ТОВАРЫ =================
  let categoriesCache = [];
  let productCat = '';
  async function viewProducts() {
    const [products, cats] = await Promise.all([api('/products'), api('/categories')]);
    categoriesCache = cats;
    const list = products.filter((p) => !productCat || String(p.category_id) === productCat);
    const filter = h('select', { onchange: (e) => { productCat = e.target.value; viewProducts().catch(fail); } },
      h('option', { value: '' }, 'Все категории'),
      cats.map((c) => h('option', { value: String(c.id), selected: productCat === String(c.id) }, c.name)));
    const rows = list.map((p) => h('tr', {},
      h('td', {}, p.image ? h('img', { class: 'thumb', src: '/uploads/' + p.image, alt: '' }) : h('div', { class: 'thumb thumb--ph' }, p.name.charAt(0))),
      h('td', {}, h('b', {}, p.name)),
      h('td', { class: 'hide-sm' }, p.category_name || '—'),
      h('td', { class: 'num' }, fmt(p.price), p.old_price ? h('div', { class: 'muted' }, h('s', {}, fmt(p.old_price))) : null),
      h('td', { class: 'num hide-sm' }, p.sort),
      h('td', {}, p.active ? h('span', { class: 'pill pill--done' }, 'Виден') : h('span', { class: 'pill pill--off' }, 'Скрыт')),
      h('td', {}, h('div', { class: 'row-actions' },
        h('button', { class: 'btn btn--ghost btn--sm', type: 'button', onclick: () => productForm(p) }, 'Изменить'),
        h('button', { class: 'btn btn--danger btn--sm', type: 'button', onclick: () => confirmDo(`Удалить «${p.name}»?`, async () => {
          await api('/products/' + p.id, { method: 'DELETE' }); toast('Удалено'); viewProducts().catch(fail);
        }) }, 'Удалить')))));
    $('#view').replaceChildren(
      h('div', { class: 'toolbar' }, filter, h('button', { class: 'btn btn--primary', type: 'button', onclick: () => productForm() }, '+ Добавить товар')),
      table(['', 'Название', { label: 'Категория', cls: 'hide-sm' }, 'Цена', { label: 'Порядок', cls: 'hide-sm' }, 'Статус', ''], rows, 'Товаров пока нет — добавьте первый'));
  }

  function productForm(p = null) {
    const preview = p?.image ? h('img', { class: 'thumb', src: '/uploads/' + p.image, alt: '' }) : h('div', { class: 'thumb thumb--ph' }, '?');
    const file = h('input', { type: 'file', name: 'image', accept: 'image/png,image/jpeg,image/webp,image/gif' });
    const removeBox = h('input', { type: 'checkbox', name: 'remove_image', value: '1' });
    file.addEventListener('change', () => {
      const f = file.files[0];
      if (!f) return;
      if (f.size > 3 * 1024 * 1024) { toast('Картинка больше 3 МБ', true); file.value = ''; return; }
      const img = h('img', { class: 'thumb', src: URL.createObjectURL(f), alt: '' });
      preview.replaceWith(img);
    });
    const err = h('p', { class: 'error' });
    const form = h('form', { novalidate: true },
      h('div', { class: 'img-edit' }, preview, h('div', {},
        h('label', { class: 'field' }, h('span', {}, 'Картинка (PNG, JPG, WEBP, GIF, до 3 МБ). Лучше квадратная, на прозрачном фоне.'), file),
        p?.image ? h('label', { class: 'switch' }, removeBox, h('span', {}, 'Удалить текущую картинку')) : null)),
      h('div', { class: 'form-grid' },
        h('label', { class: 'field full' }, h('span', {}, 'Название *'), h('input', { type: 'text', name: 'name', maxlength: 120, required: true, value: p?.name || '' })),
        h('label', { class: 'field' }, h('span', {}, 'Цена, ₽ *'), h('input', { type: 'number', name: 'price', min: 1, step: 1, required: true, value: p?.price ?? '' })),
        h('label', { class: 'field' }, h('span', {}, 'Старая цена, ₽ (для зачёркивания)'), h('input', { type: 'number', name: 'old_price', min: 1, step: 1, value: p?.old_price ?? '' })),
        h('label', { class: 'field' }, h('span', {}, 'Категория'), h('select', { name: 'category_id' },
          h('option', { value: '' }, 'Без категории'),
          categoriesCache.map((c) => h('option', { value: c.id, selected: p ? p.category_id === c.id : String(c.id) === productCat }, c.name)))),
        h('label', { class: 'field' }, h('span', {}, 'Порядок (меньше — выше)'), h('input', { type: 'number', name: 'sort', step: 1, value: p?.sort ?? 0 })),
        h('label', { class: 'field full' }, h('span', {}, 'Описание (что получит покупатель, сроки)'), h('textarea', { name: 'description', rows: 4, maxlength: 2000 }, p?.description || ''))),
      h('label', { class: 'switch' }, h('input', { type: 'checkbox', name: 'active', value: '1', checked: p ? !!p.active : true }), h('span', {}, 'Показывать на сайте')),
      err,
      h('div', { class: 'form-actions' },
        h('button', { class: 'btn btn--ghost', type: 'button', onclick: closeModal }, 'Отмена'),
        h('button', { class: 'btn btn--primary', type: 'submit' }, p ? 'Сохранить' : 'Добавить')));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.textContent = '';
      const fd = new FormData(form);
      if (!fd.get('image')?.size) fd.delete('image');
      if (!form.active.checked) fd.set('active', '0');
      try {
        await api(p ? '/products/' + p.id : '/products', { method: p ? 'PUT' : 'POST', form: fd });
        closeModal(); toast(p ? 'Сохранено' : 'Товар добавлен'); viewProducts().catch(fail);
      } catch (e2) { err.textContent = e2.message; }
    });
    openModal(p ? 'Редактировать товар' : 'Новый товар', form);
  }

  // ================= КАТЕГОРИИ =================
  async function viewCategories() {
    const cats = await api('/categories');
    const name = h('input', { type: 'text', placeholder: 'Название новой категории', maxlength: 60 });
    const add = async () => {
      if (!name.value.trim()) return;
      try { await api('/categories', { method: 'POST', body: { name: name.value, sort: cats.length } }); toast('Категория добавлена'); viewCategories().catch(fail); }
      catch (e) { fail(e); }
    };
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
    const rows = cats.map((c) => {
      const n = h('input', { type: 'text', value: c.name, maxlength: 60 });
      const s = h('input', { type: 'number', value: c.sort, step: 1, style: 'width:90px' });
      const a = h('input', { type: 'checkbox', checked: !!c.active });
      return h('tr', {},
        h('td', {}, n), h('td', {}, s), h('td', {}, h('label', { class: 'switch', style: 'margin:0' }, a, h('span', { class: 'hide-sm' }, 'видна'))),
        h('td', { class: 'num hide-sm' }, c.products),
        h('td', {}, h('div', { class: 'row-actions' },
          h('button', { class: 'btn btn--ghost btn--sm', type: 'button', onclick: async () => {
            try { await api('/categories/' + c.id, { method: 'PUT', body: { name: n.value, sort: Number(s.value) || 0, active: a.checked } }); toast('Сохранено'); }
            catch (e) { fail(e); }
          } }, 'Сохранить'),
          h('button', { class: 'btn btn--danger btn--sm', type: 'button', onclick: () => confirmDo(`Удалить категорию «${c.name}»? Товары останутся без категории.`, async () => {
            await api('/categories/' + c.id, { method: 'DELETE' }); toast('Удалено'); viewCategories().catch(fail);
          }) }, 'Удалить'))));
    });
    $('#view').replaceChildren(
      h('div', { class: 'toolbar' }, name, h('button', { class: 'btn btn--primary', type: 'button', onclick: add }, '+ Добавить')),
      table(['Название', 'Порядок', 'Видна', { label: 'Товаров', cls: 'hide-sm' }, ''], rows, 'Категорий пока нет'),
      h('p', { class: 'muted', style: 'font-size:13px' }, 'Категории — это вкладки над каталогом. Пустые категории на сайте не показываются.'));
  }

  // ================= ПРОМОКОДЫ =================
  async function viewPromos() {
    const promos = await api('/promos');
    const code = h('input', { type: 'text', placeholder: 'КОД', maxlength: 40, style: 'text-transform:uppercase' });
    const pct = h('input', { type: 'number', placeholder: 'Скидка, %', min: 1, max: 95 });
    const lim = h('input', { type: 'number', placeholder: 'Лимит (пусто — без лимита)', min: 1 });
    const add = async () => {
      try {
        await api('/promos', { method: 'POST', body: { code: code.value.trim().toUpperCase(), percent: Number(pct.value), max_uses: lim.value || null } });
        toast('Промокод создан'); viewPromos().catch(fail);
      } catch (e) { fail(e); }
    };
    const rows = promos.map((p) => h('tr', {},
      h('td', { class: 'mono' }, h('b', {}, p.code)),
      h('td', { class: 'num' }, p.percent + '%'),
      h('td', { class: 'num' }, `${p.used}${p.max_uses ? ' / ' + p.max_uses : ''}`),
      h('td', {}, p.active ? h('span', { class: 'pill pill--done' }, 'Активен') : h('span', { class: 'pill pill--off' }, 'Выключен')),
      h('td', {}, h('div', { class: 'row-actions' },
        h('button', { class: 'btn btn--ghost btn--sm', type: 'button', onclick: async () => {
          try { await api('/promos/' + p.id, { method: 'PUT', body: { ...p, active: !p.active } }); viewPromos().catch(fail); } catch (e) { fail(e); }
        } }, p.active ? 'Выключить' : 'Включить'),
        h('button', { class: 'btn btn--danger btn--sm', type: 'button', onclick: () => confirmDo(`Удалить промокод ${p.code}?`, async () => {
          await api('/promos/' + p.id, { method: 'DELETE' }); viewPromos().catch(fail);
        }) }, 'Удалить')))));
    $('#view').replaceChildren(
      h('div', { class: 'toolbar' }, code, pct, lim, h('button', { class: 'btn btn--primary', type: 'button', onclick: add }, '+ Создать')),
      table(['Код', 'Скидка', 'Использован', 'Статус', ''], rows, 'Промокодов пока нет'));
  }

  // ================= НАСТРОЙКИ =================
  async function viewSettings() {
    const s = await api('/settings');
    const inputs = {};
    const text = (key, label, opts = {}) => {
      const el = opts.rows
        ? h('textarea', { rows: opts.rows, maxlength: opts.max || 50000 }, s[key] || '')
        : h('input', { type: 'text', value: s[key] || '', maxlength: opts.max || 300 });
      inputs[key] = el;
      return h('label', { class: 'field' + (opts.full ? ' full' : '') }, h('span', {}, label), el);
    };

    // Способы получения
    const deliveries = (s.delivery_methods || []).map((d) => ({ ...d }));
    const deliveryBox = h('div');
    const renderDeliveries = () => deliveryBox.replaceChildren(...deliveries.map((d, i) => h('div', { class: 'repeat-item form-grid' },
      h('label', { class: 'field' }, h('span', {}, 'Название'), h('input', { type: 'text', value: d.name, maxlength: 60, oninput: (e) => { d.name = e.target.value; } })),
      h('label', { class: 'field' }, h('span', {}, 'Пояснение'), h('input', { type: 'text', value: d.description || '', maxlength: 200, oninput: (e) => { d.description = e.target.value; } })),
      h('div', { class: 'row-actions full' }, h('button', { class: 'btn btn--danger btn--sm', type: 'button', onclick: () => { deliveries.splice(i, 1); renderDeliveries(); } }, 'Убрать')))));
    renderDeliveries();

    // Способы оплаты
    const payments = (s.payment_methods || []).map((m) => ({ ...m }));
    const payBox = h('div');
    const renderPayments = () => payBox.replaceChildren(...payments.map((m, i) => h('div', { class: 'repeat-item form-grid' },
      h('label', { class: 'field' }, h('span', {}, 'Название для покупателя'), h('input', { type: 'text', value: m.name, maxlength: 60, oninput: (e) => { m.name = e.target.value; } })),
      h('label', { class: 'field' }, h('span', {}, 'Тип'), h('select', { onchange: (e) => { m.type = e.target.value; renderPayments(); } },
        h('option', { value: 'manual', selected: m.type === 'manual' }, 'Вручную (показать инструкцию)'),
        h('option', { value: 'yookassa', selected: m.type === 'yookassa' }, 'ЮKassa (онлайн-оплата картой/СБП)'))),
      m.type === 'manual'
        ? h('label', { class: 'field full' }, h('span', {}, 'Инструкция после оформления заказа'), h('textarea', { rows: 3, maxlength: 2000, oninput: (e) => { m.instructions = e.target.value; } }, m.instructions || ''))
        : h('p', { class: 'muted full', style: 'font-size:13px;margin:0 0 8px' }, 'Покупатель будет перенаправлен на страницу оплаты ЮKassa. Статус заказа обновится автоматически.'),
      h('div', { class: 'row-actions full' }, h('button', { class: 'btn btn--danger btn--sm', type: 'button', onclick: () => { payments.splice(i, 1); renderPayments(); } }, 'Убрать')))));
    renderPayments();
    const newId = (base) => { let i = 1; while (payments.some((m) => m.id === base + i)) i++; return base + i; };

    const save = async () => {
      const body = { delivery_methods: deliveries, payment_methods: payments };
      for (const [k, el] of Object.entries(inputs)) body[k] = el.value;
      try { await api('/settings', { method: 'PUT', body }); toast('Настройки сохранены'); loadSummary(); } catch (e) { fail(e); }
    };

    // Смена пароля
    const cur = h('input', { type: 'password', autocomplete: 'current-password' });
    const nw = h('input', { type: 'password', autocomplete: 'new-password', minlength: 10 });
    const changePw = async () => {
      try { await api('/password', { method: 'POST', body: { current: cur.value, next: nw.value } }); cur.value = nw.value = ''; toast('Пароль изменён'); }
      catch (e) { fail(e); }
    };

    $('#view').replaceChildren(
      h('section', { class: 'section' }, h('h3', {}, 'Основное'), h('p', { class: 'muted' }, 'Название и тексты на главной странице.'),
        h('div', { class: 'form-grid' },
          text('store_name', 'Название магазина', { max: 40 }),
          text('hero_kicker', 'Надзаголовок', { max: 60 }),
          text('hero_title', 'Заголовок', { max: 120, full: true }),
          text('hero_subtitle', 'Подзаголовок', { max: 300, full: true }),
          text('seller_info', 'Продавец в подвале (ФИО/название и ИНН)', { max: 300, full: true }))),
      h('section', { class: 'section' }, h('h3', {}, 'Способы получения'), h('p', { class: 'muted' }, 'Покупатель выбирает один при оформлении. Можно оставить пустым.'),
        deliveryBox, h('button', { class: 'btn btn--ghost btn--sm', type: 'button', onclick: () => { deliveries.push({ name: '', description: '' }); renderDeliveries(); } }, '+ Добавить способ')),
      h('section', { class: 'section' }, h('h3', {}, 'Способы оплаты'), h('p', { class: 'muted' }, '«Вручную» — покупатель видит вашу инструкцию (реквизиты, ссылку). «ЮKassa» — автоматическая онлайн-оплата, нужны ключи в .env.'),
        payBox,
        h('div', { class: 'toolbar' },
          h('button', { class: 'btn btn--ghost btn--sm', type: 'button', onclick: () => { payments.push({ id: newId('manual'), type: 'manual', name: '', instructions: '' }); renderPayments(); } }, '+ Ручной способ'),
          h('button', { class: 'btn btn--ghost btn--sm', type: 'button', onclick: () => { payments.push({ id: newId('yookassa'), type: 'yookassa', name: 'Банковская карта / СБП', instructions: '' }); renderPayments(); } }, '+ ЮKassa'))),
      h('section', { class: 'section' }, h('h3', {}, 'Документы и контакты'),
        h('p', { class: 'muted' }, 'Обязательно замените всё в [квадратных скобках] на свои данные. Ссылки и @username станут кликабельными.'),
        text('offer_text', 'Публичная оферта', { rows: 12 }),
        text('privacy_text', 'Политика конфиденциальности', { rows: 10 }),
        text('contacts_text', 'Контакты', { rows: 4, max: 3000 }),
        text('info_text', 'Как получить заказ', { rows: 6, max: 20000 })),
      h('div', { class: 'savebar' }, h('button', { class: 'btn btn--primary', type: 'button', onclick: save }, 'Сохранить настройки')),
      h('section', { class: 'section' }, h('h3', {}, 'Пароль администратора'),
        h('div', { class: 'form-grid' },
          h('label', { class: 'field' }, h('span', {}, 'Текущий пароль'), cur),
          h('label', { class: 'field' }, h('span', {}, 'Новый пароль (от 10 символов)'), nw)),
        h('button', { class: 'btn btn--ghost', type: 'button', onclick: changePw }, 'Сменить пароль')));
  }

  // ---------- Старт ----------
  fetch('/api/admin/me').then((r) => r.json()).then((d) => (d.authed ? showApp() : showLogin())).catch(showLogin);
})();
